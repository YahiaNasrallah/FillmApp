package com.example.projectdesign;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.projectdesign.databinding.ActivityPaymentBinding;

public class PaymentActivity extends AppCompatActivity {


    ActivityPaymentBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityPaymentBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        binding.rb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.rg2.clearCheck();
                binding.rg3.clearCheck();
                binding.rg4.clearCheck();
            }
        });


        binding.rb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.rg1.clearCheck();
                binding.rg3.clearCheck();
                binding.rg4.clearCheck();
            }
        });
        binding.rb3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.rg2.clearCheck();
                binding.rg1.clearCheck();
                binding.rg4.clearCheck();
            }
        });
        binding.rb4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.rg2.clearCheck();
                binding.rg3.clearCheck();
                binding.rg1.clearCheck();
            }
        });



        binding.btnPayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(PaymentActivity.this,ViewTicketActivity.class);
                startActivity(intent);
                finish();
            }
        });






    }
}