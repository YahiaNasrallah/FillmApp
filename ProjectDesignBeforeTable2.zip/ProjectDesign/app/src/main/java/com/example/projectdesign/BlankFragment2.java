package com.example.projectdesign;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.projectdesign.databinding.FragmentBlank2Binding;
import com.example.projectdesign.databinding.FragmentBlankAdmin2Binding;


public class BlankFragment2 extends Fragment {



    FragmentBlank2Binding binding;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding=FragmentBlank2Binding.inflate(inflater,container,false);





        return binding.getRoot();
    }
}