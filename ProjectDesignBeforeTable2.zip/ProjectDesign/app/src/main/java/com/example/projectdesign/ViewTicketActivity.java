package com.example.projectdesign;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.projectdesign.databinding.ActivityViewTicketBinding;

public class ViewTicketActivity extends AppCompatActivity {


    ActivityViewTicketBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityViewTicketBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        binding.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ViewTicketActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });



    }
}