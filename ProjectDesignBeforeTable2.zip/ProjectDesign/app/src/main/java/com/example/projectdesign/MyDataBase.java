package com.example.projectdesign;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.CursorWindow;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class MyDataBase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "filme_database";
    private static final String COLUMN_FILM_NAME = "name";
    private static final String COLUMN_FILM_ID = "id";
    private static final String COLUMN_FILM_HOUR = "hour";
    private static final String COLUMN_FILM_TYPE = "type";
    private static final String COLUMN_FILM_LANGUAGE = "language";
    private static final String COLUMN_FILM_CREATE_DATE = "createdate";
    private static final String COLUMN_FILM_CAST = "casting";
    private static final String COLUMN_FILM_CAPTION = "caption";
    private static final String COLUMN_DATE1 = "date1";
    private static final String COLUMN_DATE2 = "date2";
    private static final String COLUMN_DATE3 = "date3";
    private static final String COLUMN_DATE4 = "date4";
    private static final String COLUMN_DATE5 = "date5";
    private static final String COLUMN_TIME1 = "time1";
    private static final String COLUMN_TIME2 = "time2";
    private static final String COLUMN_TIME3 = "time3";
    private static final String COLUMN_FILM_PRICE = "price";

    private static final String COLUMN_ACTOR1_NAME = "actor1";
    private static final String COLUMN_ACTOR2_NAME = "actor2";
    private static final String COLUMN_ACTOR3_NAME = "actor3";
    private static final String COLUMN_ACTOR4_NAME = "actor4";
    private static final String COLUMN_ACTOR5_NAME = "actor5";


    private static final String COLUMN_ACTOR1_Photo = "actor1photo";
    private static final String COLUMN_ACTOR2_Photo = "actor2photo";
    private static final String COLUMN_ACTOR3_Photo = "actor3photo";
    private static final String COLUMN_ACTOR4_Photo = "actor4photo";
    private static final String COLUMN_ACTOR5_Photo = "actor5photo";


    private static final String COLUMN_FILM_PHOTO = "photo";
    private static final String COLUMN_FILM_Banner = "banner";

    private static final String TABLE_FILMS = "Filme_Table";



    public MyDataBase(Context context){
        super(context,DATABASE_NAME,null,104);

    }



    @Override
    public void onCreate(@NonNull SQLiteDatabase db) {
        db.execSQL("CREATE TABLE  Filme_Table ( name TEXT , id TEXT , hour TEXT , type TEXT , language TEXT , createdate TEXT , casting TEXT , caption TEXT , date1 TEXT ," +
                "date2 TEXT ,date3 TEXT ,date4 TEXT,date5 TEXT,time1 TEXT,time2 TEXT,time3 TEXT,price TEXT,actor1 TEXT,actor2 TEXT,actor3 TEXT,actor4 TEXT,actor5 TEXT,photo BLOB," +
                "actor1photo BLOB,actor2photo BLOB,actor3photo BLOB,actor4photo BLOB,actor5photo BLOB,banner BLOB ) ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FILMS);
        onCreate(db);
    }

    public boolean AddFilm(Filme filme){

        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_FILM_NAME,filme.getFilmName());
        values.put(COLUMN_FILM_ID,filme.getFilmID());
        values.put(COLUMN_FILM_HOUR,filme.getFilmHoure());
        values.put(COLUMN_FILM_CAST,filme.getFilmCast());
        values.put(COLUMN_FILM_TYPE,filme.getFilmType());
        values.put(COLUMN_FILM_LANGUAGE,filme.getFilmLanguge());
        values.put(COLUMN_FILM_CREATE_DATE,filme.getFilmCreateDate());
        values.put(COLUMN_ACTOR1_NAME,filme.getActor1_name());
        values.put(COLUMN_ACTOR2_NAME,filme.getActor2_name());
        values.put(COLUMN_ACTOR3_NAME,filme.getActor3_name());
        values.put(COLUMN_ACTOR4_NAME,filme.getActor4_name());
        values.put(COLUMN_ACTOR5_NAME,filme.getActor5_name());
        values.put(COLUMN_FILM_CAPTION,filme.getFilmCaption());
        values.put(COLUMN_DATE1,filme.getDate1());
        values.put(COLUMN_DATE2,filme.getDate2());
        values.put(COLUMN_DATE3,filme.getDate3());
        values.put(COLUMN_DATE4,filme.getDate4());
        values.put(COLUMN_DATE5,filme.getDate5());
        values.put(COLUMN_TIME1,filme.getTime1());
        values.put(COLUMN_TIME2,filme.getTime2());
        values.put(COLUMN_TIME3,filme.getTime3());
        values.put(COLUMN_FILM_PRICE,filme.getFilmPrice());

        values.put(COLUMN_ACTOR1_Photo,getBytes(filme.getActor1_photo()));
        values.put(COLUMN_ACTOR2_Photo,getBytes(filme.getActor2_photo()));
        values.put(COLUMN_ACTOR3_Photo,getBytes(filme.getActor3_photo()));
        values.put(COLUMN_ACTOR4_Photo,getBytes(filme.getActor4_photo()));
        values.put(COLUMN_ACTOR5_Photo,getBytes(filme.getActor5_photo()));

        values.put(COLUMN_FILM_PHOTO,getBytes(filme.getFilm_Photo()));
        values.put(COLUMN_FILM_Banner,getBytes(filme.getFilm_Banner()));




        long filmId = db.insert(TABLE_FILMS, null, values);

        db.close();
        return filmId!=0;

    }
    @SuppressLint("Range")
    public Filme getFilmByName(String filmname) {
        SQLiteDatabase db = getReadableDatabase();
        Filme filme = new Filme();

        String[] condition = {filmname + ""};
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("Select * from " + TABLE_FILMS + " where " + COLUMN_FILM_NAME + " =? ", condition);

        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
            filme.setFilmName(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_NAME)));
            filme.setFilmID(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_ID)));
            filme.setFilmHoure(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_HOUR)));
            filme.setFilmCast(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_CAST)));
            filme.setFilmType(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_TYPE)));
            filme.setFilmLanguge(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_LANGUAGE)));
            filme.setFilmCreateDate(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_CREATE_DATE)));
            filme.setActor1_name(cursor.getString(cursor.getColumnIndex(COLUMN_ACTOR1_NAME)));
            filme.setActor2_name(cursor.getString(cursor.getColumnIndex(COLUMN_ACTOR2_NAME)));
            filme.setActor3_name(cursor.getString(cursor.getColumnIndex(COLUMN_ACTOR3_NAME)));
            filme.setActor4_name(cursor.getString(cursor.getColumnIndex(COLUMN_ACTOR4_NAME)));
            filme.setActor5_name(cursor.getString(cursor.getColumnIndex(COLUMN_ACTOR5_NAME)));
            filme.setActor1_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR1_Photo))));
            filme.setActor2_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR2_Photo))));
            filme.setActor3_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR3_Photo))));
            filme.setActor4_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR4_Photo))));
            filme.setActor5_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR5_Photo))));
            filme.setFilmCaption(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_CAPTION)));
            filme.setDate1(cursor.getString(cursor.getColumnIndex(COLUMN_DATE1)));
            filme.setDate2(cursor.getString(cursor.getColumnIndex(COLUMN_DATE2)));
            filme.setDate3(cursor.getString(cursor.getColumnIndex(COLUMN_DATE3)));
            filme.setDate4(cursor.getString(cursor.getColumnIndex(COLUMN_DATE4)));
            filme.setDate5(cursor.getString(cursor.getColumnIndex(COLUMN_DATE5)));

            filme.setTime1(cursor.getString(cursor.getColumnIndex(COLUMN_TIME1)));
            filme.setTime2(cursor.getString(cursor.getColumnIndex(COLUMN_TIME2)));
            filme.setTime3(cursor.getString(cursor.getColumnIndex(COLUMN_TIME3)));
            filme.setFilmPrice(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_PRICE)));

            filme.setActor1_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR1_Photo))));
            filme.setActor2_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR2_Photo))));
            filme.setActor3_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR3_Photo))));
            filme.setActor4_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR4_Photo))));
            filme.setActor5_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR5_Photo))));
            filme.setFilm_Photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_FILM_PHOTO))));
            filme.setFilm_Banner(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_FILM_Banner))));


                cursor.moveToNext();

            }
        }



        return filme ;


    }



    @SuppressLint("Range")
    public ArrayList<Filme> getAllFilms() {
        SQLiteDatabase db = getReadableDatabase();
        ArrayList<Filme> filmeList = new ArrayList<>();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_FILMS, null);


        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                Filme filme = new Filme();
                filme.setFilmName(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_NAME)));
                filme.setFilmID(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_ID)));
                filme.setFilmHoure(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_HOUR)));
                filme.setFilmCast(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_CAST)));
                filme.setFilmType(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_TYPE)));
                filme.setFilmLanguge(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_LANGUAGE)));
                filme.setFilmCreateDate(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_CREATE_DATE)));
                filme.setActor1_name(cursor.getString(cursor.getColumnIndex(COLUMN_ACTOR1_NAME)));
                filme.setActor2_name(cursor.getString(cursor.getColumnIndex(COLUMN_ACTOR2_NAME)));
                filme.setActor3_name(cursor.getString(cursor.getColumnIndex(COLUMN_ACTOR3_NAME)));
                filme.setActor4_name(cursor.getString(cursor.getColumnIndex(COLUMN_ACTOR4_NAME)));
                filme.setActor5_name(cursor.getString(cursor.getColumnIndex(COLUMN_ACTOR5_NAME)));
                filme.setActor1_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR1_Photo))));
                filme.setActor2_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR2_Photo))));
                filme.setActor3_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR3_Photo))));
                filme.setActor4_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR4_Photo))));
                filme.setActor5_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR5_Photo))));
                filme.setFilmCaption(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_CAPTION)));
                filme.setDate1(cursor.getString(cursor.getColumnIndex(COLUMN_DATE1)));
                filme.setDate1(cursor.getString(cursor.getColumnIndex(COLUMN_DATE2)));
                filme.setDate3(cursor.getString(cursor.getColumnIndex(COLUMN_DATE3)));
                filme.setDate4(cursor.getString(cursor.getColumnIndex(COLUMN_DATE4)));
                filme.setDate5(cursor.getString(cursor.getColumnIndex(COLUMN_DATE5)));
                filme.setTime1(cursor.getString(cursor.getColumnIndex(COLUMN_TIME1)));
                filme.setTime2(cursor.getString(cursor.getColumnIndex(COLUMN_TIME2)));
                filme.setTime3(cursor.getString(cursor.getColumnIndex(COLUMN_TIME3)));
                filme.setFilmPrice(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_PRICE)));
                filme.setFilm_Photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_FILM_PHOTO))));
                filme.setFilm_Banner(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_FILM_Banner))));




                filmeList.add(filme);
                cursor.moveToNext();

            }
        }

        cursor.close();
        return filmeList;
    }



    @SuppressLint("Range")
    public ArrayList<Filme> getAllFilms2() {
        SQLiteDatabase db = getReadableDatabase();
        ArrayList<Filme> filmeList = new ArrayList<>();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_FILMS, null);


        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                Filme filme = new Filme();
                filme.setFilmName(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_NAME)));
                filme.setFilmID(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_ID)));
                filme.setFilmHoure(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_HOUR)));
                filme.setFilmCast(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_CAST)));
                filme.setFilmType(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_TYPE)));
                filme.setFilmLanguge(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_LANGUAGE)));
                filme.setActor1_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR1_Photo))));
                filme.setActor2_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR2_Photo))));
                filme.setActor3_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR3_Photo))));
                filme.setActor4_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR4_Photo))));
                filme.setActor5_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR5_Photo))));
                filme.setFilm_Photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_FILM_PHOTO))));
                filme.setFilm_Banner(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_FILM_Banner))));


                filmeList.add(filme);
                cursor.moveToNext();

            }
        }

        cursor.close();
        return filmeList;
    }




    @SuppressLint("Range")
    public ArrayList<Filme> getFilmByType(String type) {
        SQLiteDatabase db = getReadableDatabase();
        ArrayList<Filme> filmeList = new ArrayList<>();


        String[] condition = {type + ""};
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("Select * from " + TABLE_FILMS + " where " + COLUMN_FILM_TYPE + " =? ", condition);

        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                Filme filme = new Filme();
                filme.setFilmName(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_NAME)));
                filme.setFilmID(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_ID)));
                filme.setFilmHoure(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_HOUR)));
                filme.setFilmCast(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_CAST)));
                filme.setFilmType(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_TYPE)));
                filme.setFilmLanguge(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_LANGUAGE)));
                filme.setFilmCreateDate(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_CREATE_DATE)));
                filme.setActor1_name(cursor.getString(cursor.getColumnIndex(COLUMN_ACTOR1_NAME)));
                filme.setActor2_name(cursor.getString(cursor.getColumnIndex(COLUMN_ACTOR2_NAME)));
                filme.setActor3_name(cursor.getString(cursor.getColumnIndex(COLUMN_ACTOR3_NAME)));
                filme.setActor4_name(cursor.getString(cursor.getColumnIndex(COLUMN_ACTOR4_NAME)));
                filme.setActor5_name(cursor.getString(cursor.getColumnIndex(COLUMN_ACTOR5_NAME)));
                filme.setActor1_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR1_Photo))));
                filme.setActor2_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR2_Photo))));
                filme.setActor3_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR3_Photo))));
                filme.setActor4_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR4_Photo))));
                filme.setActor5_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR5_Photo))));
                filme.setFilmCaption(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_CAPTION)));
                filme.setDate1(cursor.getString(cursor.getColumnIndex(COLUMN_DATE1)));
                filme.setDate1(cursor.getString(cursor.getColumnIndex(COLUMN_DATE2)));
                filme.setDate3(cursor.getString(cursor.getColumnIndex(COLUMN_DATE3)));
                filme.setDate4(cursor.getString(cursor.getColumnIndex(COLUMN_DATE4)));
                filme.setDate5(cursor.getString(cursor.getColumnIndex(COLUMN_DATE5)));
                filme.setTime1(cursor.getString(cursor.getColumnIndex(COLUMN_TIME1)));
                filme.setTime2(cursor.getString(cursor.getColumnIndex(COLUMN_TIME2)));
                filme.setTime3(cursor.getString(cursor.getColumnIndex(COLUMN_TIME3)));
                filme.setFilmPrice(cursor.getString(cursor.getColumnIndex(COLUMN_FILM_PRICE)));

                filme.setActor1_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR1_Photo))));
                filme.setActor2_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR2_Photo))));
                filme.setActor3_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR3_Photo))));
                filme.setActor4_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR4_Photo))));
                filme.setActor5_photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ACTOR5_Photo))));
                filme.setFilm_Photo(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_FILM_PHOTO))));
                filme.setFilm_Banner(getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_FILM_Banner))));

                filmeList.add(filme);
                cursor.moveToNext();

            }
        }



        return filmeList;



    }






    public static byte[] getBytes(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, stream);
        return stream.toByteArray();
    }

    public static Bitmap getImage(byte[] image) {
        return BitmapFactory.decodeByteArray(image, 0, image.length);
    }


}
